#!/usr/bin/env python3

def welcome(hello):
    print(hello)

def main():
    welcome("Welcome to the Brain Games!")

if __name__ == '__main__':
    main()